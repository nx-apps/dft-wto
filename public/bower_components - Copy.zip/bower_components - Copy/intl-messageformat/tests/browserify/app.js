'use strict';

window.IntlMessageFormat = require('../../');
